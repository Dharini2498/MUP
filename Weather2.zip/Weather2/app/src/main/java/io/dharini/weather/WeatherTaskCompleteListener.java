package io.dharini.weather;

public interface WeatherTaskCompleteListener {
    void onWeatherTaskComplete(Weather weather);
}
