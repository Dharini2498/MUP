package io.dharini.weather;

import java.text.DecimalFormat;

import static java.lang.String.format;

public class Weather {
    private String mainWeather;
    private String descWeather;
    private Double tempmin;
    private Double tempmax;
    private String city;
    private Double temp;

    public Weather(String mainWeather, String descWeather, Double tempmin, Double tempmax, String city, Double temp) {
        this.mainWeather = mainWeather;
        this.descWeather = descWeather;
        this.tempmin = tempmin;
        this.tempmax = tempmax;
        this.city = city;
        this.temp = temp;
    }

    public String getMainWeather() {
        return mainWeather;
    }

    public void setMainWeather(String mainWeather) {
        this.mainWeather = mainWeather;
    }

    public String getDescWeather() {
        return descWeather;
    }

    public void setDescWeather(String descWeather) {
        this.descWeather = descWeather;
    }

    public String getTempmin() {
        double mi= 273;
        double tempmin1 = tempmin - mi;
        DecimalFormat numberFormat = new DecimalFormat("#.00");
        return (numberFormat.format(tempmin1));
    }

    public void setTempmin(Double tempmin) {
        this.tempmin = tempmin;
    }

    public String getTempmax() {
        double mx= 273;
        double tempmax1 = tempmax - mx;
        DecimalFormat numberFormat = new DecimalFormat("#.00");
        return (numberFormat.format(tempmax1));
    }

    public void setTempmax(Double tempmax) {
        this.tempmax = tempmax;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getTemp() {
        double mi= 273;
        double temp1 = temp - mi;
        DecimalFormat numberFormat = new DecimalFormat("#.00");
        return (numberFormat.format(temp1));
    }

    public void setTemp(Double temp) {
        this.temp = temp;
    }
}
