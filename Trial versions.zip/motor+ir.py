import RPi.GPIO as GPIO
import time

GPIO.setwarnings(False)
f=16
b=18

GPIO.setmode(GPIO.BOARD)
GPIO.setup(f,GPIO.OUT)
GPIO.setup(b,GPIO.OUT)

GPIO.setup(22,GPIO.IN)
GPIO.setup(24,GPIO.OUT)
n=int(input())

for i in range(n):
    if ((GPIO.input(22)==False) and (GPIO.input(24)==False)): 
        GPIO.output(b,GPIO.HIGH)
        print("back running motor")
        time.sleep(1.0)
        GPIO.output(b,GPIO.LOW)

    if ((GPIO.input(22)==True) and (GPIO.input(24)==True)): 
        GPIO.output(f,GPIO.HIGH)
        print("fwd running motor")
        time.sleep(1.1)
        GPIO.output(f,GPIO.LOW)

GPIO.cleanup()
    
    
    
    
        
           
