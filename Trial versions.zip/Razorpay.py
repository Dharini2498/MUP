import razorpay
client = razorpay.Client(auth=("rzp_live_jVcTTskHo4OtrA", "HmQrSdEVcb4DMt9As0xvnbKL"))
client.set_app_details({"title" : "php", "version" : "1.1.1"})
dict={}
dict=client.payment.all()
#print(dict)
qq=dict["items"][1]["status"]
print(qq)
a=dict["items"][0]["amount"]
print(a)
#a=4000
b=((a/100)/30)
print(b)


