import RPi.GPIO as GPIO
import time 
import razorpay

GPIO.setwarnings(False)
f=18
bck=22

GPIO.setmode(GPIO.BOARD)
GPIO.setup(f,GPIO.OUT)
GPIO.setup(bck,GPIO.OUT)
sleeptime=1


client = razorpay.Client(auth=("rzp_live_jVcTTskHo4OtrA", "HmQrSdEVcb4DMt9As0xvnbKL"))
client.set_app_details({"title" : "php", "version" : "1.1.1"})
dict={}
dict=client.payment.all()
#print(dict)
qq=dict["items"][0]["status"]
print(qq)
#a=dict["items"][0]["amount"]
a=3000
print(a)
b=((a/100)/30)
bb=int(b)
print(bb)


for i in range(bb):
    if (qq=="captured"):
        GPIO.output(f,GPIO.HIGH)
        print("back running motor")
        time.sleep(1.1)
        GPIO.output(f,GPIO.LOW)
    
        GPIO.output(bck,GPIO.HIGH)
        print("fwd running motor")
        time.sleep(1.0)
        GPIO.output(bck,GPIO.LOW)
GPIO.cleanup()
    

