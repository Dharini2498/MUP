import RPi.GPIO as GPIO
import time
GPIO.setwarnings(False)
GPIO.setmode(IO.BOARD)

GPIO.setup(22,IO.OUT) #GPIO 22 
GPIO.setup24,IO.OUT) #GPIO 24 

n=input(n)

for i in range(n):
    
    if ((GPIO.input(22)==False) and (GPIO.input(24)==False)): 
        print("Fwd running motor")
    
    if ((GPIO.input(22)==True) and (GPIO.input(24)==True)):
        print("Back running motor") 
        
        