import RPi.GPIO as GPIO
import time

relayPin = 7
GPIO.setmode(GPIO.BOARD) 
GPIO.setup(relayPin, GPIO.OUT)
GPIO.output(relayPin, GPIO.LOW)
GPIO.setwarnings(False)
keyCode = "Smart PopCorn"
onTime = 200 # in seconds + 20

##relayPin = digitalio.DigitalInOut(board.D4)
##relayPin.direction = digitalio.Direction.OUTPUT



while True:
    try:
        bar = input().strip()
        if (bar == keyCode):
##            print("ON")
            GPIO.output(relayPin, GPIO.HIGH)
            time.sleep(onTime)
            GPIO.output(relayPin, GPIO.LOW)
##            print("OFF")
            
    except KeyboardInterrupt:
        GPIO.cleanup()
        break
   

