import time
import os
import RPi.GPIO as GPIO
GPIO.setmode(GPIO.BOARD)

trig = 38  # sends the signal
echo = 40  # listens for the signal


GPIO.setup(echo, GPIO.IN)
GPIO.setup(trig, GPIO.OUT)
GPIO.setwarnings(False)

def measure_distance():
  """ Measure the distance per ultrasonic.  """

  GPIO.output(trig, True)
  time.sleep(0.00001)
  GPIO.output(trig, False)

  while GPIO.input(echo) == 0: pass

  start = time.time()  # reached when echo starts listening

  while GPIO.input(echo) == 1:  pass

  end = time.time() # reached when the signal arrived

  distance = ((end - start) * 34300) / 2

  return distance


if __name__ == '__main__':  

  try:
      while True:
          distance = measure_distance()
          if distance<10:
              print("Alert!!!! Restock immediately")
     os.system('/home/pi/popcorn/pushbullet.sh "Alert Motion Detected"')
              time.sleep(2)
     break
          else:
              print("distance: ",distance)
              os.system('/home/pi/popcorn/pushbullet.sh "Alert Motion not Detected"')
              time.sleep(0.5)            
  finally: 
      GPIO.cleanup()