import RPi.GPIO as GPIO
import time
import razorpay

GPIO.setwarnings(False)
f=18
bck=22
GPIO.setmode(GPIO.BOARD)
GPIO.setup(f,GPIO.OUT)
GPIO.setup(bck,GPIO.OUT)
#GPIO.setup(22,GPIO.IN)
#GPIO.setup(24,GPIO.OUT)

client = razorpay.Client(auth=("rzp_live_jVcTTskHo4OtrA", "HmQrSdEVcb4DMt9As0xvnbKL"))
client.set_app_details({"title" : "php", "version" : "1.1.1"})


dict_current={}
dict_current=client.payment.all()
#print(dict)
l=[]
s=[]
for i in range(0,10):
   ids=dict_current["items"][i]["id"]
   print(ids)
   l.append(ids)
print(l)



while(True):
    
    client = razorpay.Client(auth=("rzp_live_jVcTTskHo4OtrA", "HmQrSdEVcb4DMt9As0xvnbKL"))
    client.set_app_details({"title" : "php", "version" : "1.1.1"})
    GPIO.setmode(GPIO.BOARD)
    GPIO.setup(f,GPIO.OUT)
    GPIO.setup(bck,GPIO.OUT)


    dict={}
    dict=client.payment.all()
        
    id1=dict["items"][0]["id"]
    
    
    
    if id1 not in l:
       print("inside if")
       print("not in list is : {}".format(id1))
       qq=dict["items"][0]["status"]
       print(qq)
       a=dict["items"][0]["amount"]
       #a=3000
       print(a)
       b=int(((a/100)/1))
       bb=b*10
       print("motor running code....")
       for i in range(bb):
            if (qq=="captured"):
                print("Payment Success!!!, have a great day with smart popcorn")
                GPIO.output(bck,GPIO.HIGH)
                print("back running motor")
                time.sleep(1.0)
                GPIO.output(bck,GPIO.LOW)
       
                GPIO.output(f,GPIO.HIGH)
                print("fwd running motor")
                time.sleep(1.1)
                GPIO.output(f,GPIO.LOW)
                GPIO.cleanup()
                #append ids=1 to l list
                l.append(id1)
                
            else:
                print("payment Failed!!!, please try again after verifying bank statment")
    else:
        print("scanning for new entries and top entry is {}".format(id1))
