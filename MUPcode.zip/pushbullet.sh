#!/bin/bash

API="o.jTfXDjlrTog3wYsUvIF115OEtOCxD87m"
MSG="$1"

curl -u $API: https://api.pushbullet.com/v2/pushes -d type=note -d title="Alert" -d body="Time for Restock"